public abstract class Shape2D extends Shape{
    private boolean isfilled;
    Shape2D(String name,boolean isfilled){
        super(name);
        this.isfilled=isfilled;

    }





}
